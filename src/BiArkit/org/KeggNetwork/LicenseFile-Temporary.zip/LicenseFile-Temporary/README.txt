Welcome to the Serva Software TWaver

TWaver version 4.3.5
Serva Software LLC.

TWaver requires the Java 2 platform (1.4 or later).

This package contains the official release of TWaver. 
The source code for the demo are also provided in this package.

Contents of the package

  ./documents  - Product and developer documents for TWaver
  ./javadoc    - API reference manual for TWaver (.html)
  ./lib        - TWaver library file.
  ./src        - Source code of the demo application.


From TWaver 1.4.1, TWaver license should be validated before start 
your application. Please make sure you have received a license file from 
TWaver sales representative. The license is a file which contains TWaver 
license type, additional information and fingerprint data.

Three types of licenses have been defined in TWaver:

a. Evaluation License: You may use TWaver in your organization for evaluation purpose. It is fully functional and an evaluation hint text will be displayed on all components. If no license file is validated, Evaluation License will be applied. Press ctrl+shift+t key to bring out license information dialog.

b. Development License: You may install and use TWaver for development purpose on licensed computer within your organization. It is fully functional and no hint text will be shown on all components but a license dialog will be pop up in 2 hours after your application started. Press ctrl+shift+t key to bring out license information dialog.

c. Runtime License: You may install and deploy your application to your end users. It is fully functional and no hint text or dialog will be shown. Press ctrl+shift+t key to bring out license information dialog.

Active your TWaver license with following steps:

1. Put the license file to a location where can be accessed with a proper Java URL. Following URLs are all legal license location:
 - "file:/c:/myapp/data/license.dat"
 - "http://www.mycompany.com/application/license.dat"
 - "/com/myapp/oss/data/license.dat"

2. Validate the license with following code when start your applications:
    
    TWaverUtil.validateLicense ("file:/c:/myapp/data/license.dat");
    Note: A proper exception will be thrown if the license validation does not succeed.

Note:
1. The license type is defined in the license file. 
2. If any content of the license file has been changed or damaged, validation will failed.

Technical Support

  Send us e-mail to:  support@servasoftware.com   or   info@servasoftware.com

  It would be helpful if you told us:
    - which JDK/JVM you are using
    - which development environment
    - how to reproduce the problem (if any) with some concise code

For more information about TWaver, please visit us at
http://www.servasoftware.com/
